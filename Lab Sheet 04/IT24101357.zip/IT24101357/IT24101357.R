# Replace the path with your folder location
setwd("C:\\Users\\it24101357\\Desktop\\IT24101357")
#Q1
# Import the dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

# Check the first few rows of the data
head(branch_data)
fix(data)

#Q2
str(branch_data)

#Q3
boxplot(branch_data$Sales_X1, main = "Boxplot for Sales", ylab = "Sales_X1")

#Q4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Q5
outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR<-Q3-Q1 
  lower<- Q1 - 1.5 * IQR
  upper<- Q3 + 1.5 * IQR
  
  y<- x[x < lower | x > upper]
  return(y)
}

# Check for outliers in the 'years' variable
outliers(branch_data$Years_X3)

